(function($){
  $(function(){

    $('.sidenav').sidenav();
    $('.slider').slider();
    $('.carousel').carousel();
    
  }); // end of document ready
})(jQuery); // end of jQuery name space
